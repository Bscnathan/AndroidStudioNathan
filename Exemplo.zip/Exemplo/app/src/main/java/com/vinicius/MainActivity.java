package com.vinicius;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import model.AppDatabase;
import model.Pessoa;
import model.PessoaDao;

public class MainActivity extends AppCompatActivity {



    Button btnAcessar;
    Button btnListar;

    TextView txtNome;
    EditText campo_nome;
    TextView txtTelefone;
    EditText campo_telefone;
    TextView txtEmail;
    EditText campo_email;



    static AppDatabase db;

    PessoaDao pessoaDao;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

Thread t = new Thread(){
    public void run(){
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class,
                "contatos").build();

    pessoaDao = db.pessoaDao();

    }
};
t.start();

    txtNome = findViewById(R.id.txtNome);
    campo_nome = findViewById(R.id.campo_nome);

    txtEmail = findViewById(R.id.txtEmail);
    campo_email = findViewById(R.id.campo_email);

    txtTelefone = findViewById(R.id.txtTelefone);
    campo_telefone = findViewById(R.id.campo_telefone);

    btnAcessar = findViewById(R.id.btnAcessar);
    btnListar = findViewById(R.id.btnListar);

        // 3 - CRIAR A Acao
        btnAcessar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 4 - CHAMAR A OUTRA TELA
 Intent intent = new Intent(getApplicationContext(), ListaActivity.class);
 startActivity(intent);
// recupera os dados digitados

 String nome = campo_nome.getText().toString();
 String telefone = campo_telefone.getText().toString();
 String Email = campo_email.getText().toString();
 Pessoa pessoa = new Pessoa(nome, telefone, Email);

 Thread t2 = new Thread() {
     public void run() {

         pessoaDao.insertTodos(pessoa);
         Toast.makeText(getApplicationContext(), "Sucesso", Toast.LENGTH_SHORT).show();
     }
 };
t2.start();

    }
});

btnListar.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(getApplicationContext(), ListaActivity.class);
        startActivity(intent);
    }
});
    }

}
