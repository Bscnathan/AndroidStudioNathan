package com.vinicius;

import static com.vinicius.MainActivity.db;

import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import java.util.ArrayList;

import adapters.PessoaAdapter;
import model.AppDatabase;
import model.Pessoa;
import model.PessoaDao;

public class ListaActivity extends AppCompatActivity {

    ListView listView;
    PessoaAdapter adapter;
    ArrayList<Pessoa> listaPessoas;
    PessoaDao pessoaDao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista);


        Thread t = new Thread(){
            public void run(){
                pessoaDao = db.pessoaDao();
                listaPessoas =  new ArrayList<>(pessoaDao.getTodos());
            }
        };
        t.start();

    listView = findViewById(R.id.listView);
    adapter = new PessoaAdapter(getApplicationContext(), listaPessoas);
    listView.setAdapter(adapter);
    }
}